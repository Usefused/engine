"""Generated Harnest application entrypoint; do not edit."""

from pathlib import Path

from harnest.bundle import compile_application

from harnest.agent_plugin_runtime import plugin_installation

with plugin_installation('7382f79d660b3b952f69545f92b80a6466f61743b588e265b88600c88c85ada6'):
    application = compile_application(
        Path(__file__).parent / "source",
        entrypoint='agent:root_agent',
        framework='adk',
        mode='managed',
    )
app = application.native_app or application.target
root_agent = application.target
