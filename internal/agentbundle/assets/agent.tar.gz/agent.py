"""Generated Harnest application entrypoint; do not edit."""

from pathlib import Path

from harnest.bundle import compile_application

from harnest.agent_plugin_runtime import plugin_installation

with plugin_installation('b8b01b0159cf90d3c403bddd563c7a860c724965f22f28b42473e01c1f9ef3e5'):
    application = compile_application(
        Path(__file__).parent / "source",
        entrypoint='agent:root_agent',
        framework='adk',
        mode='managed',
    )
app = application.native_app or application.target
root_agent = application.target
